g_tex = {}
g_edit = {}
g_dead = {}
g_timeBgn = 0
g_up_speed = 1
g_down_speed = 0
g_bgspeed = 0.3
g_bg2speed = 0.5

g_font = nil
g_font2 = nil

g_count	= nil
g_count2 = nil

Ari_speed={fir=0,sec=3,thr=6,fur=9,fiv=12,six=0,sev=0}
egg_position={fir=0,sec=100,thr=200,fur=300,fiv=400}
stage_speed = {one=0,two=0.05,thr=0.1,fur=0.1,fiv=0.15,six=0.2}

contect = 0
coll_limit_point = 0

down_speed = 0.05
up_speed = 0.02
rock_dead = -150

jump_Count = 0
limit_point= 0
stage_count = 0
next_stage = 1
near_bg_dead = 800
far_bg_dead = 1000
dead_point = 0

speed_limit = 1
dead_limit = 0

count = 0
jump = 0
press = 3
off = 0
boost = 0

click_count =0
a = 1
b = 0

function Lua_Create()
	Lsys.ScriptFile(1,"main.lua")
	Lsys.SetClearColor("0xFF669933")
	Lsys.CreateWindow(-1,-1,800,480,"Chicken Run(Beta)",0) 
	Lsys.ShowState(0)
	

	return 0
end



function Lua_Init()
	
	------------------------------------------------------
	---------------------------Font---------------------------
	g_font = Lfont.New("default", 20)
	Lfont.String(g_font,"Score : ")
	Lfont.Position(g_font,530,20)

	g_font2 = Lfont.New("default", 20)
	Lfont.Position(g_font2,680,20)

	g_count = Lfont.New("default", 20)
	Lfont.String(g_count,"����Ƚ�� : ")
	Lfont.Position(g_count,530,50)

	g_count2 = Lfont.New("default", 20)
	Lfont.Position(g_count2,700,50)

	g_end = Lfont.New("default", 30)
	Lfont.Position(g_end,250,200)
	g_total = Lfont.New("default", 30)
	Lfont.Position(g_total,230,235)
	Lfont.Color(g_end,"0xFFFF0000")
	------------------------------------------------------
	------------------------------------------------------
	
	-----------------------------------------------------------------------------
	--------����-----------------------------------------------------------------
	g_tex[2] = {tex = Ltex.New("jump.png"),x=10,y=350,w=60,h=85}
	-----------------------------------------------------------------------------
	--------���-----------------------------------------------------------------
	g_tex[3] = {tex = Ltex.New("new_bag.png"),x=0,y=0}
	g_tex[4] = {tex = Ltex.New("new_bag2.png"),x=1000,y=0}
	g_tex[5] = {tex = Ltex.New("geo_tree.png"),x=0,y=0}
	g_tex[6] = {tex = Ltex.New("geo_tree2.png"),x=1000,y=0}
	g_edit[1] = {tex = Ltex.New("line_up.png"),x=-90,y=0}
	g_edit[2] = {tex = Ltex.New("line_up2.png"),x=930,y=0}
	-----------------------------------------------------------------------------
	--------�޸���---------------------------------------------------------------
	g_tex[7] = {tex = Ltex.New("stop.png"),x=10,y=350,w=120,h=85}
	g_tex[8] = {tex = Ltex.New("run.png"),x=10,y=350,w=120,h=85}
	g_tex[9] = {tex = Ltex.New("bigrun.png"),x=10,y=350,w=120,h=85}
	-----------------------------------------------------------------------------
	--------������Ʈ-------------------------------------------------------------
	g_tex[10] = {tex = Ltex.New("rock_1.png"),x=810,y=350,w=150,h=120}--��1
	g_tex[11] = {tex = Ltex.New("rock_2.png"),x=1300,y=350,w=150,h=120}--��2
		--------------------------------------------------------------------------
		--------Live--------------------------------------------------------------
		g_tex[12] = {tex = Ltex.New("live1.png"),x=egg_position.fir,y=0}
		g_tex[13] = {tex = Ltex.New("live2.png"),x=egg_position.sec,y=0}
		g_tex[14] = {tex = Ltex.New("live3.png"),x=egg_position.thr,y=0}
		g_tex[15] = {tex = Ltex.New("live4.png"),x=egg_position.fur,y=0}
		g_tex[16] = {tex = Ltex.New("live5.png"),x=egg_position.fiv,y=0}
		--------------------------------------------------------------------------
		--------Dead--------------------------------------------------------------
		g_tex[17] = {tex = Ltex.New("dead1.png"),x=egg_position.fir,y=0}
		g_tex[18] = {tex = Ltex.New("dead2.png"),x=egg_position.sec,y=0}
		g_tex[19] = {tex = Ltex.New("dead3.png"),x=egg_position.thr,y=0}
		g_tex[20] = {tex = Ltex.New("dead4.png"),x=egg_position.fur,y=0}
		g_tex[21] = {tex = Ltex.New("dead5.png"),x=egg_position.fiv,y=0}
	--------------------------------------------------------------------------
	--------bag(2),cloud--------------------------------------------------------------
	g_tex[22] = {tex = Ltex.New("cloud.png"),x=0,y=0}
	g_tex[23] = {tex = Ltex.New("cloud2.png"),x=800,y=0}
	
	g_dead[1] = {tex = Ltex.New("d_stop.png"),x=10,y=350,w=120,h=85}
	g_dead[2] = {tex = Ltex.New("d_run.png"),x=10,y=350,w=120,h=85}
	g_dead[3] = {tex = Ltex.New("d_bigrun.png"),x=10,y=350,w=120,h=85}
	g_dead[4] = {tex = Ltex.New("d_jump.png"),x=10,y=350,w=60,h=85}

	
	g_timeBgn = Lsys.GetTime()

	if Click_e == press then
		jump_Count = jump_Count + 1
	end
	return 0
end

function Lua_Destroy()
	return 0
end




function Lua_FrameMove()
	Lsys.Sleep(27)
	local curTime = Lsys.GetTime()
	local deltaTime = curTime - g_timeBgn
	item_random = Lutil.Rand(800,2000)
	item_random2 = Lutil.Rand(500,600)
	local loop = 1

--------------------------------------------------------------------
----���������� �Ѿ�鼭 �ӵ��� ������Ŵ(���ӵ�,��渮������ǥ)--
	if next_stage == 1 and speed_limit == 1 then
		g_bgspeed = g_bgspeed + stage_speed.one
		g_bg2speed = g_bg2speed + stage_speed.one
		near_bg_dead = near_bg_dead - g_bg2speed*7
		far_bg_dead = far_bg_dead - g_bg2speed*7
		speed_limit = 2
	elseif next_stage == 2 and speed_limit == 2 then
		g_bgspeed = g_bgspeed + stage_speed.two
		g_bg2speed = g_bg2speed + stage_speed.two
		near_bg_dead = near_bg_dead - g_bg2speed*7
		far_bg_dead = far_bg_dead - g_bg2speed*7
		speed_limit = 3
	elseif next_stage == 3 and speed_limit == 3 then
		g_bgspeed = g_bgspeed + stage_speed.thr
		g_bg2speed = g_bg2speed + stage_speed.thr
		near_bg_dead = near_bg_dead - g_bg2speed*7
		far_bg_dead = far_bg_dead - g_bg2speed*7
		speed_limit = 4
	elseif next_stage == 4 and speed_limit == 4 then
		g_bgspeed = g_bgspeed + stage_speed.fur
		g_bg2speed = g_bg2speed + stage_speed.fur
		near_bg_dead = near_bg_dead - g_bg2speed*7
		far_bg_dead = far_bg_dead - g_bg2speed*7
		speed_limit = 5
	elseif next_stage == 5 and speed_limit == 5 then
		g_bgspeed = g_bgspeed + stage_speed.fiv
		g_bg2speed = g_bg2speed + stage_speed.fiv
		near_bg_dead = near_bg_dead - g_bg2speed*7
		far_bg_dead = far_bg_dead - g_bg2speed*7
		speed_limit = 6
	elseif next_stage == 6 and speed_limit == 6 then
		g_bgspeed = g_bgspeed + stage_speed.six
		g_bg2speed = g_bg2speed + stage_speed.six
		near_bg_dead = near_bg_dead - g_bg2speed*7
		far_bg_dead = far_bg_dead - g_bg2speed*7
		speed_limit = 7
	end

	--print(g_tex[10].x ,"///",g_tex[11].x,"\n" )

	Click_e = Lin.MouseEvnt()

	if 1 == Click_e then --Ŭ�� Ƚ�� �����ϴ� ����
		click_count = click_count +1
			
	end
	--[[
	if g_tex[2].y >= 350 and click_count >= 7 then --6ȸ ������ �����ϰ� GameOver�������
		Lfont.String(g_end,"GameOver\n" )
		Lfont.String(g_total,"Total Score : " .. math.floor(g_timeBgn/(10/0.1)))
		
		return 0
	end
	--]]
	
	
	
	--���� �� UI(������)
	--���� ��
	--����ȭ
	--ó�� ���� �ִϸ��̼�
	
	
	count = count + 1 --ĳ������ ����� �������� ���ϸ� �ʱ�ȭ �Ǿ� ó������ ������ ���� ����
	if count >= Ari_speed.fiv then
		count = 1
	end
	
------------����------------------------------------------------------------------
------------------------------------------------------------------------------
	g_tex[3].x = g_tex[3].x - g_bgspeed * deltaTime
	if g_tex[3].x < -1000 then
		g_tex[3].x = far_bg_dead
	end
	
	g_tex[4].x = g_tex[4].x - g_bgspeed * deltaTime
	if g_tex[4].x < -1000 then
		g_tex[4].x = far_bg_dead
	end

	g_edit[1].x = g_edit[1].x - g_bgspeed * deltaTime
	if g_edit[1].x < -1000 then
		g_edit[1].x = far_bg_dead
	end

	g_edit[2].x = g_edit[2].x - g_bgspeed * deltaTime
	if g_edit[2].x < -1000 then
		g_edit[2].x = far_bg_dead
	end
------------����------------------------------------------------------------------
------------------------------------------------------------------------------
	g_tex[22].x = g_tex[22].x - g_bgspeed * deltaTime / 5
	if g_tex[22].x < -1024 then
		g_tex[22].x = far_bg_dead
	end
	
	g_tex[23].x = g_tex[23].x - g_bgspeed * deltaTime / 5
	if g_tex[23].x < -1024 then
		g_tex[23].x = far_bg_dead
	end

-------------������ ����-----------------------------------------------------------------
------------------------------------------------------------------------------
	

	g_tex[5].x = g_tex[5].x - g_bg2speed * deltaTime
	if g_tex[5].x < -1000 then
		g_tex[5].x = near_bg_dead
	end
	
	g_tex[6].x = g_tex[6].x - g_bg2speed * deltaTime
	if g_tex[6].x < -1000 then
		g_tex[6].x = near_bg_dead
	end
-----------��-------------------------------------------------------------------
------------------------------------------------------------------------------

	if a == 1  then
		g_tex[10].x = g_tex[10].x - g_bg2speed * deltaTime
		if g_tex[10].x < rock_dead then
			g_tex[10].x = item_random
			stage_count = stage_count + 1			
			a = 2
		end

		if g_tex[10].x < 500 then
			
			b = 1
		end
		
	end 
	
	
	if b == 1 then
		g_tex[11].x = g_tex[11].x - g_bg2speed * deltaTime
		if g_tex[11].x < rock_dead then
			g_tex[11].x = item_random
			stage_count = stage_count + 1
			b = 2
		end
		
		if g_tex[11].x < 200 then
			a = 1
		end
		
	end
		
	--------���� ���ɹ� ����-------------------------------------------------------------
	if  0 < g_tex[2].y and g_tex[2].y <= 4000 then
		
		-----���������϶�-----------------------------------------------------------------		
		if Click_e == press and limit_point == 0 then
			
			g_tex[2].y = g_tex[2].y - g_up_speed * deltaTime 
			g_up_speed = g_up_speed - down_speed --����ϸ� �ӵ��� �����Ͽ� �߷��� �޴� ȿ�� ����
			----�ְ����� ���������� �ڵ������� ���������� ����(limit_point Ȱ��ȭ)--------
			if g_up_speed <= -0.0 and limit_point == 0 then
				limit_point = 1
				print("Ȯ��")
			end 
			jump  = 1
			------�� �����϶�------------------------------------------------------------
		elseif Click_e == off or limit_point == 1 then
			g_tex[2].y = g_tex[2].y + g_down_speed * deltaTime
			coll_limit_point = 1			
			if jump == 1 then
				g_down_speed = g_down_speed + up_speed
			end
			-----�ٴڿ� �����ϸ� ����----------------------------------------------------
			if g_tex[2].y >= 350 then
				g_tex[2].y = 350
				g_up_speed = 0.8
				g_down_speed = 0.01
				jump  = 0
				coll_limit_point = 0
				-----Ŭ���� ���߸� �ٽ� �ö󰥼� �ֵ��� ����-------------------------------
				if Click_e == off then
					limit_point = 0
					g_up_speed = 0.8
				end			
			end			
		end		
	end
	
	print("stage : ",next_stage,"count = ",stage_count,"\n")
	
	g_timeBgn = curTime
	Lfont.String(g_font2,"" .. math.floor(curTime/(10/0.1)))

	Lfont.String(g_count2,"" ..  6 - click_count)
	
	if stage_count == 6 then --���� 6�� �������� ���� ���������� ��
		stage_count = 0 
		click_count = 0
		next_stage = next_stage + 1
		dead_limit = 0
	end
	if click_count >= 7 and Click_e == 1 then
		dead_point = dead_point + 1
	end

	if Click_e == off and coll_limit_point == 0 then
		if RectCollision(g_tex[7], g_tex[10],g_tex[11]) == 1 and contect == 0 then
			dead_point = dead_point + 1
			contect = 1
		elseif RectCollision(g_tex[7], g_tex[10],g_tex[11]) == 2 then
			contect = 0
			coll_limit_point = 0
		end
	end

	if Click_e == press then
		if RectCollision(g_tex[2], g_tex[10],g_tex[11]) == 1 and contect == 0 then
			dead_point = dead_point + 1
			contect = 1
		elseif RectCollision(g_tex[2], g_tex[10],g_tex[11]) == 2 then
			contect = 0
			coll_limit_point = 0
		end
	end

		
end

function Lua_Render()

	------------------------------------------------------------
	----------���Ÿ����----------------------------------------
	Ltex.Draw(g_tex[4].tex, g_tex[4].x, g_tex[4].y)
	Ltex.Draw(g_tex[3].tex, g_tex[3].x, g_tex[3].y)
	Ltex.Draw(g_tex[22].tex, g_tex[22].x, g_tex[22].y)
	Ltex.Draw(g_tex[23].tex, g_tex[23].x, g_tex[23].y)
	Ltex.Draw(g_edit[1].tex, g_edit[1].x, g_edit[1].y)--��輱 ����
	Ltex.Draw(g_edit[2].tex, g_edit[2].x, g_edit[2].y)--��輱 ����2
	------------------------------------------------------------
	----------����������----------------------------------------
	Ltex.Draw(g_tex[5].tex, g_tex[5].x, g_tex[5].y)
	Ltex.Draw(g_tex[6].tex, g_tex[6].x, g_tex[6].y)
	Ltex.Draw(g_tex[10].tex, g_tex[10].x, g_tex[10].y)--��1
	Ltex.Draw(g_tex[11].tex, g_tex[11].x, g_tex[11].y)--��2
		
	------------------------------------------------------------
	----------ĳ����--------------------------------------------
	if contect == 0 then
		if jump == 1 then
			Ltex.Draw(g_tex[2].tex, g_tex[2].x, g_tex[2].y)
			count = -1 
		end
		if count >=Ari_speed.fir and count < Ari_speed.sec then
			Ltex.Draw(g_tex[7].tex, g_tex[7].x, g_tex[7].y)
		elseif count >= Ari_speed.sec and count < Ari_speed.thr or count <= Ari_speed.fiv and count >= Ari_speed.fur then
			Ltex.Draw(g_tex[8].tex, g_tex[8].x, g_tex[8].y)
		elseif count >= Ari_speed.thr and count < Ari_speed.fur then
			Ltex.Draw(g_tex[9].tex, g_tex[9].x, g_tex[9].y)
		end
	end
	-----------------------------------------------------
	----------������ ������ ----------------------------
	
	if contect == 1 then
		if jump == 1 then
			Ltex.Draw(g_dead[4].tex, g_dead[4].x, g_dead[4].y)
			count = -1 
		end
		if count >=Ari_speed.fir and count < Ari_speed.sec then
			Ltex.Draw(g_dead[1].tex, g_dead[1].x, g_dead[1].y)
		elseif count >= Ari_speed.sec and count < Ari_speed.thr  or count <= Ari_speed.fiv and count >= Ari_speed.fur then
			Ltex.Draw(g_dead[2].tex, g_dead[2].x, g_dead[2].y)
		elseif count >= Ari_speed.thr and count < Ari_speed.fur then
			Ltex.Draw(g_dead[3].tex, g_dead[3].x, g_dead[3].y)
		end
	end
	
	-----------------------------------------------------
	----------�������ھ� �� ������UI----------------------------
	Ltex.Draw(g_tex[12].tex, g_tex[12].x, g_tex[12].y)
	Ltex.Draw(g_tex[13].tex, g_tex[13].x, g_tex[13].y)
	Ltex.Draw(g_tex[14].tex, g_tex[14].x, g_tex[14].y)
	Ltex.Draw(g_tex[15].tex, g_tex[15].x, g_tex[15].y)
	Ltex.Draw(g_tex[16].tex, g_tex[16].x, g_tex[16].y)
	

	if dead_point >= 1 then
		Ltex.Draw(g_tex[17].tex, g_tex[17].x, g_tex[17].y)
	end
	if dead_point >= 2 then
		Ltex.Draw(g_tex[18].tex, g_tex[18].x, g_tex[18].y)
	end
	if dead_point >= 3 then
		Ltex.Draw(g_tex[19].tex, g_tex[19].x, g_tex[19].y)
	end
	if dead_point >= 4 then
		Ltex.Draw(g_tex[20].tex, g_tex[20].x, g_tex[20].y)
	end
	if dead_point >= 5 then
		Ltex.Draw(g_tex[21].tex, g_tex[21].x, g_tex[21].y)
	end

	Lfont.Draw(g_font)
	Lfont.Draw(g_font2)
	Lfont.Draw(g_count)
	Lfont.Draw(g_count2)
	Lfont.Draw(g_end)
	Lfont.Draw(g_total)
	return 0
end





function RectCollision(run,obj,obj2)	-- rc ={x= .. , y=.., w=.., h=..,}
	if run.x < (obj.x + obj.w) and obj.x < (run.x + run.w) and
		run.y < (obj.y + obj.h) and obj.y < (run.y + run.h) then
		print("OK1\n")
		return 1
	end
	if run.x < (obj2.x + obj2.w) and obj2.x < (run.x + run.w) and
		run.y < (obj2.y + obj2.h) and obj2.y < (run.y + run.h) then
		print("OK2\n")
		return 1
	end
	
	return 2
end

