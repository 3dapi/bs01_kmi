
-- 
-- ���� �߱� data
--

-- define for game phase
GAMEPHASE_BEGIN = 1
GAMEPHASE_PLAY  = 2
GAMEPHASE_END   = 3
GAMEPHASE_EXIT  = 4


g_gamePhase	= GAMEPHASE_BEGIN	-- phase
g_score		= 0					-- game score

g_count		= 0					-- remain number

