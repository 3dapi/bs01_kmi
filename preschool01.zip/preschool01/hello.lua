-- the first program in every language

print ("Hello world\n")

io.write("LUA Version:",_VERSION,"!\n")
